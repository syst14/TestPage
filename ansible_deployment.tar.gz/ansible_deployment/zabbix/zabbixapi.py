#!/usr/bin/env python

import urllib, json, httplib, socket, sys, os

def httpRequest(request):
    body = json.dumps(request)
    headers = {"Content-type": "application/json"}
    conn = httplib.HTTPConnection("SERVER_ADRESS", 80)
    conn.request("POST", "/api_jsonrpc.php", body, headers)
    response = conn.getresponse()
    data = response.read()
    conn.close()
    return data


me = os.popen('hostname').read().strip('\n')

# server's authorization

authToken = httpRequest({"jsonrpc": "2.0","method":"user.login","params":{"user":"Admin","password":"zabbix"},"id":0})
authToken = json.loads(authToken).get('result', None)

# getting hostid

mhost = httpRequest({"jsonrpc":"2.0","method":"host.get","params":{"output":"extend","filter":{"host":me}},"auth":authToken,"id":1})
mhost = json.loads(mhost)
if mhost:
    # assigning host according to system
    hostID = mhost['result'][0]['hostid']
    print "HostID is ",hostID
    print "We need to update host info, link templates and move host to proper group"
    print "Collecitng host info..."
    osFamily = os.popen('uname').read().strip('\n')
    print "Base OS is",osFamily
    if osFamily == "Linux":
        hostGroups = [{"groupid":"2"}]
        hostTemplates = [{"templateid":"10001"}]
        print "Host assigned to group"
    else:
        print "Base OS is unknown"
    print "Detected groups are", hostGroups
    print "Detected templates are", hostTemplates
    # updating host data
    updateHost = {"jsonrpc":"2.0","method":"host.update","params":{"hostid":hostID,"groups":hostGroups,"templates":hostTemplates},"auth":authToken,"id":2}
    print "Trying to update host..."
    httpRequest(updateHost)
    sys.exit(0)

else:
    print "Failed detect host"
    print "Nothing to do..."
    sys.exit(0)
